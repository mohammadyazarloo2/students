const searchinput = document.querySelector(".search-gol");
searchinput.value = "";
searchinput.addEventListener("focus", function () {
  this.parentElement.querySelector("label").classList.add("labelmove");
});
searchinput.addEventListener("blur", function () {
  if (searchinput.value == "") {
    this.parentElement.querySelector("label").classList.remove("labelmove");
  }
});

let day = document.querySelector(".day");
let night = document.querySelector(".night");
day.addEventListener("click", function () {
  document.body.classList.add("active");
});
night.addEventListener("click", function () {
  document.body.classList.remove("active");
});

let btnBasket = document.querySelector(".basket-s");
let btnBasketClose = document.querySelector(".basket-content-close");

btnBasket.addEventListener("click", function (e) {
  const isClickedInsideDiv = e
    .composedPath()
    .includes(document.querySelector("header"));

  console.log(isClickedInsideDiv);
  this.classList.add("active");
  document.querySelector(".basket-sidebar").classList.add("active");
  document.querySelector("main").classList.add("basketSidebar");
});

btnBasketClose.addEventListener("click", function () {
  this.classList.remove("active");
  document.querySelector(".basket-sidebar").classList.remove("active");
  document.querySelector("main").classList.remove("basketSidebar");
});

document.addEventListener("click", (e) => {
  const isClickedInsideDiv = e
    .composedPath()
    .includes(document.querySelector("header"));
  console.log(isClickedInsideDiv);
  const close = e
    .composedPath()
    .includes(document.querySelector(".basket-content-close"));
  console.log(isClickedInsideDiv);

  if (isClickedInsideDiv == false || close == true) {
    btnBasketClose.classList.remove("active");
    document.querySelector(".basket-sidebar").classList.remove("active");
    document.querySelector("main").classList.remove("basketSidebar");
  } else {
    btnBasket.classList.add("active");
    document.querySelector(".basket-sidebar").classList.add("active");
    document.querySelector("main").classList.add("basketSidebar");
  }
});

// window.scrollTo({
//     left:40,
//     top:300,
//     behavior:'smooth'
// })
let oldScroll = window.scrollY;
console.log(oldScroll);
window.addEventListener("scroll", (e) => {
  if (oldScroll > window.scrollY) {
    document.querySelector("header").classList.add("fixed-header");
  } else {
    document.querySelector("header").classList.add("fixed-header-hide");
    document.querySelector("header").classList.remove("fixed-header");
  }
  if (window.scrollY === 0) {
    document.querySelector("header").classList.remove("fixed-header-hide");
    document.querySelector("header").classList.remove("fixed-header");
  }
  oldScroll = window.scrollY;
});

function showVisible() {
  for (let img of document.querySelectorAll("img")) {
    let realSrc = img.dataset.src;
    if (!realSrc) continue;

    setTimeout(function () {
      realSrc += "?nocache=" + Math.random();

      img.src = realSrc;

      img.dataset.src = "";
    }, 2000);
  }
}

window.addEventListener("scroll", showVisible);

//   add basket section
if (document.readyState == "ready") {
  document.addEventListener("DOMContentLoaded", ready);
} else {
  ready();
}

function ready() {
  let btnAddBasket = document.querySelectorAll(".btn-addbasket");
  for (let i = 0; i < btnAddBasket.length; i++) {
    var button = btnAddBasket[i];
    button.addEventListener("click", clickedBasketItem);
  }
}
function clickedBasketItem(e) {
  let button = e.target;
  let shopItems =
    button.parentElement.parentElement.parentElement.parentElement;
  let imgsrc = shopItems.querySelector(".product-img img").src;
  let name = shopItems.querySelector(".product-title").innerText;
  let price = shopItems.querySelector(".product-price").innerText;
  addBasket(imgsrc, name, price);
}

function addBasket(imgsrc, name, price) {
  let divp = document.createElement("div");
  divp.classList.add("basketcart-items");
  let bsname = document.querySelectorAll(".basketcart-item-name span")
    .innerText;
  let basketItems = document.querySelectorAll(".basket-loader")[0];
  for (let i = 0; i < bsname; i++) {
    if (name == bsname[i]) {
      alert("exist");
      return;
    }
  }

  let content = `
                    <div class="basketcart-item-img">
                        <img src="${imgsrc}" width="50" height="50">
                    </div>
                    <div class="basketcart-item-name">
                        <span> ${name} </span>
                    </div>
                    <div class="basketcart-item-price">
                        <span> ${price} </span>
                    </div>
                    <div class="basketcart-item-quantity"> <span>1</span> </div>
                    <div class="basketcart-item-remove">
                        <button class="btn-basketcart-remove">
                            <span class="material-symbols-outlined">
                                close
                            </span>
                        </button>
                    </div>
    `;
  divp.innerHTML = content;
  basketItems.append(divp);
}
